﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



namespace WebApplication2
{
    public partial class lOGIN : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BTN1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["db1ConnectionString1"].ToString());
                SqlCommand cmd = new SqlCommand("select * from Registration where userid=@username and password=@word", con);
                cmd.Parameters.AddWithValue("@username", TXT1.Text);
                cmd.Parameters.AddWithValue("@word", TXT2.Text);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
               
                if (dt.Rows.Count > 0){
                    foreach (DataRow dr in dt.Rows)
                    {
                        char x = Convert.ToChar(dr["usertype"]);
                        if (x == 'A' || x == 'a')

                            Response.Redirect("Admin.aspx");
                        else if (x == 'U' || x == 'u')
                            Response.Redirect("User.aspx");
                        else { }


                    }


                
                }
                else
                {
                    Response.Write("InValid user");
                    Response.Redirect("lOGIN.aspx");
                   

                }  
  









/*
                // string x = "Select * from Registration";
                //SqlCommand cmd = con.CreateCommand();
                //cmd.CommandType = CommandType.Text;
                string q = "select * from Registration where userid='" + TXT1.Text + "' and password='" + TXT2.Text + "' ";
                SqlCommand cmd = new SqlCommand(q,con);
                SqlDataReader dr;
                dr=cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    System.Windows.Forms.MessageBox.Show("Valid user");
                   // dr.Read();
                     //Session["userid"] = dr["userid"].ToString();
                   // Response.Redirect("Admin.aspx");

                }
                else
                    System.Windows.Forms.MessageBox.Show("InValid user");

              /*  DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                //da.SelectCommand = cmd;
                // DataSet ds = new DataSet();
                da.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    Session["userid"] = dr["userid"].ToString();
                    Response.Redirect("Admin.aspx");
                }*/
                /*  int uid;
                 string pwd;
                 uid = Convert.ToInt32(ds.Tables[0].Rows[0]["userid"]);
                 pwd = ds.Tables[0].Rows[0]["password"].ToString();
                 con.Close();
                 if (uid == Convert.ToInt32(TXT1.Text) && pwd == TXT2.Text)
                 {
                     Session["TXT1"] = uid;

                     Response.Redirect("Admin.aspx");

                 }
                 else
                    Response.Write("Invalid User");*/
            } 
            catch { }
           

        }
        
    }
}