﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace TMS
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["db1ConnectionString4"].ToString());
                String insert = "insert into course values(@courseCode,@courseDescription,@skillSet,@courseDate,@courseTime,@addedBy,@otherReference)";
                //String insert1 = "insert into registration(userId,firstName,lastName,age,gender,password,email,userType) values(@userId,@firstName,@lastName,@age,@gender,@password,@email,@userType)";

                SqlCommand cmd = new SqlCommand(insert, con);
                // SqlCommand cmd1 = new SqlCommand(insert1


                cmd.Parameters.AddWithValue("@courseCode", courseCode1.Text);
                cmd.Parameters.AddWithValue("@courseDescription", courseDescription.Text);
                cmd.Parameters.AddWithValue("@skillSet", skillSet.Text);
                cmd.Parameters.AddWithValue("@courseDate", courseDate.Text);
                cmd.Parameters.AddWithValue("@courseTime", courseTime.Text);
                cmd.Parameters.AddWithValue("@addedBy", addedBy.Text);
                cmd.Parameters.AddWithValue("@otherReference", otherReference.Text);


               
                con.Open();


                int result = cmd.ExecuteNonQuery();


                con.Close();

                Page.ClientScript.RegisterStartupScript(Page.GetType(), "scripts", "<Script>alert('Your  course details are updated successfully');</script>");

            }
            catch 
            {
               // System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}