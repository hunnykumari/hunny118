﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class signout : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "Scripts", "<Script>alert('You have successfully sign out')</Script>");
                //Response.Redirect("lOGIN.aspx");
                Site1 s = (Site1)this.Master;
                HyperLink c = (HyperLink)FindControl("HyperLink1");

                c.Visible = false;

                Site1 s1 = (Site1)this.Master;
                HyperLink c1 = (HyperLink)FindControl("HyperLink2");

                c1.Visible = false;

                Site1 s3 = (Site1)this.Master;
                HyperLink c3 = (HyperLink)FindControl("HyperLink3");

                c3.Visible = false;
            }
            catch { }

            //HyperLink2.Visible = false;
            //HyperLink3.Visible = false;
        }
    }
}